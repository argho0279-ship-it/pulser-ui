# Carbon UI

A modern, accessible React component library built with Tailwind CSS and TypeScript. **Carbon UI** provides a collection of unstyled, composable components that are perfect for building beautiful, responsive user interfaces.

## Features

* 🎨 **Tailwind CSS Styled** - Built with Tailwind CSS for consistent, customizable styling
* 📱 **Responsive Design** - Mobile-first approach with responsive utilities
* 🌙 **Dark Mode Support** - All components support light and dark modes
* ♿ **Accessible** - WCAG compliant components with proper ARIA attributes
* 📖 **Storybook Integration** - Interactive component documentation and testing
* 🔒 **TypeScript** - Full TypeScript support with complete type definitions
* 📦 **Tree-Shakeable** - Optimized for minimal bundle size with ES modules
* ⚡ **Vite + Rollup** - Fast development experience and optimized production builds

---

# Installation

### Using npm

```bash
npm i carbon
```

---

# Peer Dependencies

This library requires the following peer dependencies to be installed in your project:

* `react` >= 18.2.0
* `react-dom` >= 18.2.0
* `react-hook-form` >= 7.0.0
* `zod` >= 3.0.0
* `tailwindcss` >= 4.0.0

---

# Quick Start

## Basic Setup

### 1. Install Tailwind CSS v4

```bash
npm install -D tailwindcss @tailwindcss/vite
```

---

### 2. Configure your `vite.config.ts`

```ts
import { defineConfig } from 'vite'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [
    tailwindcss(),
  ],
})
```

---

### 3. Import Carbon UI components

```tsx
import { Button, Input, Form } from 'carbon';

function App() {
  return (
    <div>
      <Button variant="primary">Click me</Button>
      <Input placeholder="Enter text..." />
    </div>
  );
}
```

---

# Components

## Form Components

### Input

A flexible input field component with optional label and error display.

**Props**

* `label?` – Label text displayed above the input
* `error?` – Error message displayed below the input
* All standard HTML input attributes

Example:

```tsx
import { Input } from 'carbon';

<Input
  label="Email"
  type="email"
  placeholder="Enter your email..."
  error="Email is required"
/>
```

---

### Form

A form wrapper component with built-in validation using React Hook Form and Zod.

Example:

```tsx
import { Form, Input } from 'carbon';
import { z } from 'zod';

const schema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

function MyForm() {
  const onSubmit = (data) => console.log(data);

  return (
    <Form schema={schema} onSubmit={onSubmit}>
      <Input name="email" label="Email" />
      <Input name="password" label="Password" type="password" />
      <button type="submit">Submit</button>
    </Form>
  );
}
```

---

### Button

A versatile button component with multiple variants and sizes.

Example:

```tsx
import { Button } from 'carbon';

<Button variant="primary" size="large" onClick={() => console.log('Clicked!')}>
  Submit
</Button>
```

---

# Layout Components

## Card

Example:

```tsx
import { Card, CardHeader, CardTitle, CardContent } from 'carbon';

<Card>
  <CardHeader>
    <CardTitle>Card Title</CardTitle>
  </CardHeader>
  <CardContent>
    Your content here
  </CardContent>
</Card>
```

---

## Modal

Example:

```tsx
import {
  Modal,
  ModalTrigger,
  ModalContent,
  ModalHeader,
  ModalTitle,
  ModalBody,
  ModalFooter,
  ModalClose
} from 'carbon';

<Modal>
  <ModalTrigger>Open Modal</ModalTrigger>

  <ModalContent>
    <ModalHeader>
      <ModalTitle>Modal Title</ModalTitle>
    </ModalHeader>

    <ModalBody>Content here</ModalBody>

    <ModalFooter>
      <ModalClose>Close</ModalClose>
    </ModalFooter>
  </ModalContent>
</Modal>
```

---

# Navigation Components

## Navbar

```tsx
import { Navbar, NavbarItem } from 'carbon';

<Navbar>
  <NavbarItem href="/">Home</NavbarItem>
  <NavbarItem href="/about">About</NavbarItem>
</Navbar>
```

---

## Dropdown

```tsx
import {
  Dropdown,
  DropdownTrigger,
  DropdownMenu,
  DropdownItem,
  DropdownSeparator
} from 'carbon';

<Dropdown>
  <DropdownTrigger>
    <button>Open Menu</button>
  </DropdownTrigger>

  <DropdownMenu>
    <DropdownItem>Profile</DropdownItem>
    <DropdownItem>Settings</DropdownItem>
    <DropdownSeparator />
    <DropdownItem>Logout</DropdownItem>
  </DropdownMenu>
</Dropdown>
```

---

## Hamburger Menu

```tsx
import { HamburgerMenu, MobileMenu } from 'carbon';
import { useState } from 'react';

function MyComponent() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <HamburgerMenu
        isOpen={isOpen}
        onToggle={() => setIsOpen(!isOpen)}
      />

      <MobileMenu isOpen={isOpen}>
        <nav>
          <a href="/">Home</a>
          <a href="/about">About</a>
        </nav>
      </MobileMenu>
    </>
  );
}
```

---

# Data Display Components

## Avatar

```tsx
import { Avatar } from 'carbon';

<Avatar
  src="https://example.com/avatar.jpg"
  alt="User Avatar"
  fallback="John Doe"
  size="medium"
/>
```

---

## Progress

```tsx
import { Progress, Spinner, Skeleton } from 'carbon';

<Progress value={75} variant="success" showValue />
<Spinner size="medium" />
<Skeleton width="w-32" height="h-4" />
```

---

## Alert

```tsx
import { Alert, AlertTitle, AlertDescription } from 'carbon';

<Alert variant="success">
  <AlertTitle>Success!</AlertTitle>
  <AlertDescription>
    Your changes have been saved successfully.
  </AlertDescription>
</Alert>
```

---

## Toast

```tsx
import { ToastProvider, ToastContainer, useToast } from 'carbon';

function App() {
  return (
    <ToastProvider>
      <MyComponent />
      <ToastContainer />
    </ToastProvider>
  );
}

function MyComponent() {
  const { addToast } = useToast();

  return (
    <button onClick={() => addToast('Hello World!', 'success')}>
      Show Toast
    </button>
  );
}
```

---

# ImageSlider

```tsx
import { ImageSlider } from 'carbon';

const images = [
  { src: 'image1.jpg', alt: 'Image 1', caption: 'First image' },
  { src: 'image2.jpg', alt: 'Image 2', caption: 'Second image' }
];

<ImageSlider images={images} autoPlay showDots showArrows />
```

---

# Development

```bash
npm install
npm run dev
npm run build
npm run preview
npm run storybook
npm run build-storybook
```

---

# Project Structure

```
src/
├── components/
│   ├── Button.tsx
│   ├── Input.tsx
│   ├── Card.tsx
│   ├── Modal.tsx
│   ├── Form.tsx
│   ├── Navbar.tsx
│   ├── Avatar.tsx
│   ├── Alert.tsx
│   ├── Toast.tsx
│   ├── Progress.tsx
│   ├── Slider.tsx
│   ├── ImageSlider.tsx
│   ├── Dropdown.tsx
│   ├── HamburgerMenu.tsx
│   ├── Tooltip.tsx
│   └── index.ts
├── index.css
└── index.ts
```

---

# Build Output

The library is built as both ES modules and UMD format:

* **ES Module:** `dist/carbon.js`
* **UMD:** `dist/carbon.umd.cjs`
* **Types:** `dist/index.d.ts`

---

# Customization

All components use Tailwind CSS classes and respect your Tailwind configuration.

Example:

```js
export default {
  theme: {
    extend: {
      colors: {
        primary: '#0066cc',
        secondary: '#666',
      },
    },
  },
}
```

---

# Browser Support

* Chrome (latest)
* Firefox (latest)
* Safari (latest)
* Edge (latest)

---

# License

MIT

---

# Contributing

Contributions are welcome. Feel free to submit a pull request.

---

# Support

For issues or feature requests please open an issue on your repository.

---

**Carbon UI — Built with ❤️ using React and Tailwind CSS**
